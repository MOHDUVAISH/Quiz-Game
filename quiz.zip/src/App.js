import React from 'react'
import Quiz from './components/Quiz'
import "./App.css"
function App() {
  return (
    <>
      <Quiz/>
    </>
  )
}

export default App